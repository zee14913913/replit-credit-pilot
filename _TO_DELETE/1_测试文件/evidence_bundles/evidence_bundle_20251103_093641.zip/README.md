# Evidence Bundle

- Generated: 2025-11-03T09:36:41.763763
- Files: 11
- Purpose: Circuit-breaker demo & 3-scenario uploads (A/B/C) evidence
- Notes:
  - Use `manifest.json` to verify SHA256 checksums.
  - All API responses follow UploadResponse schema (status/next_actions/raw_document_id).

